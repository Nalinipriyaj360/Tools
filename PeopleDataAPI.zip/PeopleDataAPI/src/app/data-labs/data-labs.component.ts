import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-data-labs',
  templateUrl: './data-labs.component.html',
  styleUrls: ['./data-labs.component.css']
})
export class DataLabsComponent implements OnInit {
  user: any;
  profileFile: any;
  profile: any;
  company: any;
  title: any;
  clicked = false;
  clicked1 = false;
  clicked2 = false;
  public profileData: Profile[] = [];
  companyFile: any;
  public companyData: Company[] = [];
  titleFile: any;
 // public titleData: Title[] = [];
  constructor(public service:DataServiceService) { }
  public ngForm = new FormGroup({
    file: new FormControl('', [Validators.required]),
    profileFile: new FormControl('')
  })
  public ngForm1 = new FormGroup({
    file: new FormControl('', [Validators.required]),
    companyFile: new FormControl('')
  })
  public ngForm2 = new FormGroup({
    file: new FormControl('', [Validators.required]),
    titleFile: new FormControl('')
  })
  ngOnInit(): void {
    console.log("user", this.user);
  }
  onChangeProfile(files: FileList) {
    if (files && files.length > 0) {
      let file: File = files.item(0);
      this.profileFile = file;
      let reader: FileReader = new FileReader();
      reader.readAsText(file);
      reader.onload = (e) => {
        this.profile = reader.result as string;
        let csvToRowArray = this.profile.split("\n");
        console.log(csvToRowArray);
        for (let index = 1; index < csvToRowArray.length - 1; index++) {
          let row = csvToRowArray[index].split(",");
          //  console.log("row",row);
          this.profileData.push(new Profile(row[0], row[1], row[2], row[3]));
        }
        console.log(this.profileData);
      }
    }
    console.log("file profile", this.profileFile);
    this.ngForm.value.profileFile = this.profileFile.name;
  }
  onChangeCompany(files: FileList) {
    //this.company = event.target.files[0]
    if (files && files.length > 0) {
      let file: File = files.item(0);
      this.companyFile = file;
      let reader: FileReader = new FileReader();
      reader.readAsText(file);
      reader.onload = (e) => {
        this.company = reader.result as string;
        let csvToRowArray = this.company.split("\n");
        console.log(csvToRowArray);
        for (let index = 1; index < csvToRowArray.length - 1; index++) {
          let row = csvToRowArray[index].split(",");
          //  console.log("row",row);
          this.companyData.push(new Company(row[0], row[1]));
        }
        console.log(this.companyData);
      }
    }
    console.log("file company", this.companyFile.name);
    this.ngForm1.value.companyFile = this.companyFile.name;
  }
  onChangeTitle(files:FileList) {
    //this.title = event.target.files[0]
    if (files && files.length > 0) {
      let file: File = files.item(0);
      this.titleFile = file;
      let reader: FileReader = new FileReader();
      reader.readAsText(file);
      reader.onload = (e) => {
        this.title = reader.result as string;
        let csvToRowArray = this.title.split("\n");
        console.log(csvToRowArray);
        for (let index = 1; index < csvToRowArray.length - 1; index++) {
          let row = csvToRowArray[index].split(",");
          //  console.log("row",row);
       //   this.titleData.push(new Title(row[0], row[1]));
        }
        //console.log(this.titleData);
      }
    }
    console.log("file title", this.titleFile.name);
    this.ngForm2.value.titleFile = this.titleFile.name;
  }
  profileSubmit() {
    //alert("profile")
    console.log("profile file", this.profileFile.name);
     this.service.getPeopleDataLabs().subscribe(response=>{
      console.log("response profile",response);
    }) 
  }
  companySubmit() {
    console.log("company file", this.companyFile.name);
  }
  titleSubmit() {
    console.log("title file", this.title);
  }

}

export class Profile {
  FirstName: String;
  LastName: String;
  FullName: String;
  Company: String;
  constructor(FirstName: String, LastName: String, FullName: String, Company: String) {
    this.FirstName = FirstName;
    this.LastName = LastName;
    this.FullName = FullName;
    this.Company = Company;
  }
}
export class Company {
  CompanyName: String;
  TitleRole: String;

  constructor(CompanyName: String, TitleRole: String) {
    this.CompanyName = CompanyName;
    this.TitleRole = TitleRole;
  }
}
