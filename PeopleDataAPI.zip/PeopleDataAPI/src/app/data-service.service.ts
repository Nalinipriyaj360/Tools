import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Client } from 'elasticsearch-browser';
//import * as elasticsearch from 'elasticsearch-browser';
import requests from "requests";
//import json from "json";
@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  private client: Client;
  response: any;
  API_KEY = "48a7d6de5276f50b8e4e4e709c7d9cb2d208e6ab75fbbbb3cecc57297ffb6357"

  PDL_URL = "https://api.peopledatalabs.com/v5/person/search"

  H = {
    'Content-Type': "application/json",
    'X-api-key': this.API_KEY
  }
  DESIRED_COMPANY_DOMAINS = [
    'stripe.com', 'plaid.com', 'xignite.com', 'square.com'
  ]
 public ES_QUERY = {
    'query': {
      'bool': {
        'must': [
          { 'terms': { 'job_company_website': this.DESIRED_COMPANY_DOMAINS } },
          { 'term': { 'job_title_role': 'engineering' } },
          { 'terms': { 'job_title_levels': ["vp", "director", "manager"] } },
          { 'exists': { 'field': 'work_email' } }
        ]
      }
    }
  }
  
//jsonData = new HttpResponse<JsonData>;
   P = {
    'query': JSON.stringify(this.ES_QUERY),
    'size': 100
  }
  constructor(public http: HttpClient) {
   
  }
  params = new HttpParams().set("query", encodeURIComponent(JSON.stringify(this.P)));
   private connect() {
    this.client = new Client({
      host: 'https://api.peopledatalabs.com/v5/person/search',
      log: 'trace'
    });
  }
   getPeopleDataLabs(){
    console.log("qury",this.ES_QUERY,this.params)
     return this.http.get("https://api.peopledatalabs.com/v5/person/search",
      { headers: this.H ,observe:"body",responseType:"json",params:this.params
      }) 
   // return this.client.search({body:this.ES_QUERY,headers:this.H})
   }
  }
    /*return this.http.get("https://api.peopledatalabs.com/v5/person/search",
      { headers: this.H ,params: this.params
      }
      
    );*/
    //console.log("response serveice",this.response);

 /*  getPeopleDataLabs(){

    //const options = createRequestOption(req);
    return this.http
        .request<[]>("GET","https://api.peopledatalabs.com/v5/person/search" ,
        {
            body: this.P,
            headers: this.H,
            observe: 'response'
        });
} */










